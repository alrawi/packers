CodeCrypt v0.16 beta for Win9x by defiler
-----------------------------------------

Version 0.164 beta for Win9x:

CodeCrypt is a non-user-friendly console application.
Usage:
CodeCrypt.exe <PE-File> <parametres>

Parametres are :
	s : choose this option to leave antisice code out 	(default=off)
	c : this option adds a cdcheck routine to target .exe	(default=off)

e.g: CodeCrypt.exe leckmichmalsorichtigfett.exe cs
This example does not use anti-sice code, and adds a cdcheck routine.
You need to put a cd into your FIRST cd-rom drive if you want to use this
parametre.The executable will then only be runnable with this cd.

What CodeCrypt does:
--------------------
It encrypts code sections of a PE-File and adds decryption code,
to leave the file in (at least in most cases ;) an executable state.
It's just another lame PE-Crypter.

currently implemented features:

- anti-debugging code.
- anti-tracer code (procdump etc).
- encryption of the decrypter.
- random number encryption system.
- multiple checksum encryption.
- bogus opcodes, making it harder to reverse the decrypter.
- anti procdump-dump-trick
- anti-frogsice code

not yet supported:

- encryption of Dynamic Link Libraries.
- multiple encryption.


some words to cardenal mendoza:
the decrypter for 0.163 didn't defeat the crypter... it doesn't work 100%
so go.. and figure it out... next time i want a 100% working decrypter =)


For any bug reports, comments and ideas:

defiler@elitereversers.de