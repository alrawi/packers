***************************************************
**         PE-PROTECTOR v1.0 for Win9X/ME        **
**                                               **                                               
**                by Rafael Ahucha               **
**                                               ** 
**        (c) 2001, University of Seville        **
***************************************************


Introduction
------------

PE-PROTECTOR is a encrypter/protector for Windows 9x/ME to protect executable files PE
against reverse engineering or cracking with a very strong protection.

PE-PROTECTOR has been designed to avoid all kind of vulnerabilities in all the current
encrypters/protectors.



Protections in PE-PROTECTOR
---------------------------

* Target file encrypted with user password (and automatic generation of a specific KeyGen)
* Target file encrypted with random key
* Anti-debugger techniques
* Anti-disassembler techniques
* Anti-generic dumper techniques
* Anti-VxD dumper techniques
* Anti-FrogsICE techniques
* Anti-Monitors techniques
* Anti-API spy techniques
* Random code insertion between each real instruction
* PE sections encryption
* Anti-patch techniques
* Virus detection
* Protection with multiple threads
* Polymorphic decryptors
* Threads decryptors
* Anti-hardware breakpoint decryptors
* Insertion of polymorphic anti-debugger code between each real instruction
* Insertion of polymorphic anti-disassembler code between each real instruction
* Random code insertion after each routine
* Target file patched in runtime
* Jump opcodes readjusted in runtime to reply code
* Up to 300 layers of encryptation
* Execution of code in Ring-0



Limitations in PE-PROTECTOR
---------------------------

PE-PROTECTOR is only compatible with Windows 9x/ME and cannot run under 
Windows NT/2000. In a future, PE-PROTECTOR will be implemented as a device 
driver to make it compatible with all the Windows versions.

PE-PROTECTOR has some problems to protect some PE files due to bad information
in their PE header. To avoid that, make sure that all the programs that you 
are going to protect do not have their PE header manipulated.

There are some cases where the PE header is right but the program does not 
run properly after protecting it with PE-PROTECTOR. This can be due to some
internal checksums that some programs have or another kind of protection
to avoid the external manipulation of them.



Additional information
----------------------

To obtain more information about all the proteccions offered by PE-PROTECTOR 
and how you can use them to protect your programs, please, read the "Help.hlp"
file.



Suggestions, bugs, etc
----------------------

If you find any problem when you try to protect a program or you have any kind
of suggestions about PE-PROTECTOR, please mail me at:

rahucha@hotmail.com

 




 
